package be.camco.valueobjects;

public class Site {
	private String urlString;
	private String locationString;
	//private String versionUrlString;
	
	public String getUrlString() {
		return urlString;
	}
	public void setUrlString(String urlString) {
		this.urlString = urlString;
	}
	public String getLocationString() {
		return locationString;
	}
	public void setLocationString(String locationString) {
		this.locationString = locationString;
	}
//	public String getVersionUrlString() {
//		return versionUrlString;
//	}
//	public void setVersionUrlString(String versionUrlString) {
//		this.versionUrlString = versionUrlString;
//	}
	
	
}

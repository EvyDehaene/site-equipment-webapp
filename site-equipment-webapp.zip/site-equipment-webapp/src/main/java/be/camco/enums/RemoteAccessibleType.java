package be.camco.enums;

public enum RemoteAccessibleType {
	HTTP, RADMIN, VNC
}

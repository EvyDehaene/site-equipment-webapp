package be.camco.enums;

public enum IOType {
	INPUT, OUTPUT
}

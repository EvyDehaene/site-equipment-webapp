package be.camco.enums;

public enum DeviceType {
	KIOSK,SERVER,BARRIER,INTERCOM,WAGO
}
